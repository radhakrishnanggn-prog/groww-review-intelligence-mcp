# Customer clarification: Mutual fund expense ratio on Groww
- A mutual fund's expense ratio is a cost of managing and operating the scheme; it is expressed as a percentage of the scheme's assets.
- It is generally reflected in the scheme's Net Asset Value (NAV); it is not ordinarily a separate amount debited from the investor's bank account.
- Groww states that investing in mutual funds on its platform is free of Groww platform charges, but the fund may have costs such as an expense ratio, exit load, stamp duty and taxes.
- Groww announced on 1 October 2026 that the headline figure displayed on its fund details page changed from Total Expense Ratio (TER) to Base Expense Ratio (BER). BER is one component of TER; other components can include brokerage, transaction costs and statutory levies.
- A fund's applicable costs and exit-load terms can vary by scheme and transaction. Check the scheme documents and the latest fund details before making a decision.
- This explanation is general information, not investment advice. If a displayed figure or transaction does not match your records, contact Groww support with the scheme name and transaction details.

**Official sources**
1. Groww — What are the charges for mutual fund investments? https://groww.in/help/mutual-funds/searchable/what-are-the-charges-for-mutual-fund-investments--93
2. Groww — BER vs TER: what changed? https://groww.in/updates/groww-now-shows-base-expense-ratio-instead-of-total-expense-ratio

**Last checked:** 16 October 2026
