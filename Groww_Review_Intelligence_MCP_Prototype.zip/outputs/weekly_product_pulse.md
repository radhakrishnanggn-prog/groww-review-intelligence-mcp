# Weekly Product Pulse — Groww
**Reporting window:** 20 Aug–15 Sep 2026 (demo dataset; dates are illustrative for synthetic rows)

## Top themes
1. **Fees / expense-ratio clarity** — 5 demo-seed reviews raise questions about whether a mutual-fund expense ratio is a separate Groww charge and why the displayed number changed.
2. **Trading reliability / performance** — public review excerpts mention order execution issues and slow app behavior.
3. **Redemption and support resolution** — public review excerpts mention redemption timelines and unresolved account/support issues.

## Supporting user quotes
- “The app gets stuck at trade execution and orders do not execute even after setting a profit/loss limit.” — public Google Play excerpt, 18 Aug 2026.
- “The app is slow and redeeming money takes five days.” — public Google Play excerpt, 9 Sep 2026.
- “The expense ratio number looks different from before. Is Groww charging me this separately?” — **synthetic demo row; not a real customer quote**.

## Key observation
The demo data suggests that product performance and transaction-status communication are important experience issues. The synthetic fee examples are included only to demonstrate detection and content generation; they do **not** establish that this fee confusion recurs in real reviews. Replace synthetic rows with verified public reviews before presenting findings as research.

## Product actions
1. Audit order-submission and execution failure states; show clear order status and recovery guidance.
2. Make redemption status and expected timelines visible, with proactive updates when delayed.
3. Add a contextual mutual-fund cost explainer beside the expense-ratio label, distinguishing fund-level costs from charges collected by Groww.

**Evidence caveat:** This pulse is a prototype example, not a statistically representative review study.
