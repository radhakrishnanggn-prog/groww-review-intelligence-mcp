# Source list
1. Google Play — Groww Stocks, Mutual Fund, IPO reviews: https://play.google.com/store/apps/details?id=com.nextbillion.groww
2. Apple App Store — Groww Stocks, Mutual Fund, IPO reviews: https://apps.apple.com/in/app/groww-stocks-mutual-fund-ipo/id1404871703
3. Groww — Mutual fund investment charges: https://groww.in/help/mutual-funds/searchable/what-are-the-charges-for-mutual-fund-investments--93
4. Groww — Mutual fund redemption charges: https://groww.in/help/mutual-funds/order/what-are-the-charges-applicable-for-redeeming--53
5. Groww — Pricing and brokerage: https://groww.in/pricing
6. Groww — BER vs TER update (1 October 2026): https://groww.in/updates/groww-now-shows-base-expense-ratio-instead-of-total-expense-ratio
