import streamlit as st
import pandas as pd
import json, os
from datetime import date
from pathlib import Path

ROOT = Path(__file__).parent
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)
st.set_page_config(page_title="Groww Review Intelligence", page_icon="🧭", layout="wide")
st.title("Groww Review Intelligence")
st.caption("Review → themes → product pulse + fee explainer → human approval → internal log + email draft")

st.warning("Demo mode: rows marked `synthetic_demo` are fabricated examples used to demonstrate the fee-confusion workflow. Do not treat them as real customer evidence. Replace them with verified public reviews before presenting findings as research.")

uploaded = st.file_uploader("Upload reviews CSV", type=["csv"])
if uploaded:
    df = pd.read_csv(uploaded)
else:
    df = pd.read_csv(ROOT / "data" / "reviews_sample.csv")
st.subheader("Review input")
st.dataframe(df, use_container_width=True, hide_index=True)
if "review_text" not in df.columns:
    st.error("CSV must contain a review_text column.")
    st.stop()
if "record_type" not in df.columns:
    df["record_type"] = "unverified"

def theme(text):
    t = str(text).lower()
    if any(k in t for k in ["expense ratio","fee","charge","brokerage","tax","hidden","cost","ter","ber","exit load"]): return "Fees / cost clarity"
    if any(k in t for k in ["slow","lag","stuck","hang","crash","execution","execute","glitch","order"]): return "Performance / trading reliability"
    if any(k in t for k in ["redeem","redemption","withdraw","credited","settlement"]): return "Redemption / money movement"
    if any(k in t for k in ["support","response","ticket","complaint","resolved","customer service"]): return "Support / issue resolution"
    return "Navigation / usability"

df["theme"] = df["review_text"].apply(theme)
counts = df["theme"].value_counts()
top = counts.head(3)
fee_rows = df[df["theme"] == "Fees / cost clarity"]
synthetic_count = int((df["record_type"].astype(str).str.lower() == "synthetic_demo").sum())
st.subheader("Review intelligence")
c1,c2,c3 = st.columns(3)
c1.metric("Reviews loaded", len(df))
c2.metric("Themes found", min(5, df["theme"].nunique()))
c3.metric("Fee-related rows", len(fee_rows))
st.write("### Theme counts")
st.bar_chart(counts)
st.write("### Top 3 themes")
st.dataframe(top.rename("review_count").reset_index().rename(columns={"index":"theme"}), hide_index=True, use_container_width=True)
st.write("### Candidate fee-related evidence")
if fee_rows.empty:
    st.info("No fee-related reviews were detected. The workflow will not invent a fee issue. Add verified reviews or rerun with a larger review set.")
else:
    st.dataframe(fee_rows[["date","rating","source","review_text","record_type"]], hide_index=True, use_container_width=True)
    if synthetic_count:
        st.warning(f"{synthetic_count} synthetic demo row(s) are present. Fee recurrence is not verified until synthetic rows are replaced with authentic reviews.")

quotes = df.sort_values("rating", ascending=True).head(3) if "rating" in df.columns else df.head(3)
quote_text = "\n".join([f'- “{r["review_text"]}” — {r.get("source","unknown")}; {r.get("record_type","unverified")}' for _,r in quotes.iterrows()])
theme_text = "\n".join([f"- {name}: {int(n)} review(s)" for name,n in top.items()])
fee_issue = "Expense-ratio / total-vs-base expense ratio clarity (DEMO SIGNAL; validate using authentic reviews)" if len(fee_rows) else "No recurring fee issue substantiated in this input"
pulse = f"""# Weekly Product Pulse — Groww
**Date:** {date.today().isoformat()}

## Top themes
{theme_text}

## Supporting quotes (verify record_type before external use)
{quote_text}

## Key observation
The current sample suggests that customer friction may cluster around {', '.join(top.index.tolist())}. Counts are directional and depend on the uploaded sample. {"Synthetic rows are present, so fee-related findings are demonstration-only." if synthetic_count else "No synthetic rows detected; still validate review authenticity and sample coverage."}

## Product actions
1. Instrument the highest-volume issue and track incidence, severity, and resolution time.
2. Improve in-context status/explanation at the point where users encounter the issue.
3. Add a support macro and monitor repeat contacts, helpfulness, and complaint rate.
"""
fee_explainer = """- A mutual fund expense ratio is a scheme-level operating cost expressed as a percentage of scheme assets.
- It is reflected in the scheme's Net Asset Value (NAV), rather than ordinarily appearing as a separate bank-account debit.
- Groww says mutual-fund investing on its platform is free of Groww platform charges; scheme-level costs and taxes or exit loads may still apply.
- Groww's 1 October 2026 update says the headline figure on the fund page changed from Total Expense Ratio (TER) to Base Expense Ratio (BER). BER is one component of TER.
- Applicable charges depend on the scheme and transaction; check the current scheme documents and fund details.
- This is general factual information, not investment advice. For a transaction-specific discrepancy, contact Groww support with the scheme and transaction details.

Official sources:
1. https://groww.in/help/mutual-funds/searchable/what-are-the-charges-for-mutual-fund-investments--93
2. https://groww.in/updates/groww-now-shows-base-expense-ratio-instead-of-total-expense-ratio

Last checked: 16 October 2026
"""
st.subheader("Generated outputs")
with st.expander("Weekly product pulse", expanded=True): st.markdown(pulse)
with st.expander("Fee explainer", expanded=True): st.markdown(fee_explainer)
st.download_button("Download weekly pulse", pulse, file_name="weekly_product_pulse.md")
st.download_button("Download fee explainer", fee_explainer, file_name="fee_explainer.md")

entry = {
    "date": date.today().isoformat(),
    "top_themes": [{"theme":str(k),"count":int(v)} for k,v in top.items()],
    "weekly_pulse": pulse,
    "identified_fee_issue": fee_issue,
    "explanation_bullets": [x[2:] for x in fee_explainer.splitlines() if x.startswith("- ")],
    "source_links": [
        "https://groww.in/help/mutual-funds/searchable/what-are-the-charges-for-mutual-fund-investments--93",
        "https://groww.in/updates/groww-now-shows-base-expense-ratio-instead-of-total-expense-ratio"
    ]
}
email_body = f"Weekly product pulse\n\n{pulse}\n\nFee explanation (reusable support snippet)\n\n{fee_explainer}\n\nDRAFT ONLY — not sent."
email_text = "Subject: Weekly Product Pulse + Customer Clarification — Groww\n\n" + email_body
st.subheader("MCP-style approval gate")
st.write("Nothing is written to the internal log or email draft until you check approval and click the approval button.")
approve = st.checkbox("I reviewed the themes, quotes, fee wording, and source links. I approve saving the outputs.", value=False)
col1,col2 = st.columns(2)
with col1:
    if st.button("Approve & append to Notes log", disabled=not approve, type="primary"):
        logpath = OUT / "notes_log.jsonl"
        with open(logpath,"a",encoding="utf-8") as f: f.write(json.dumps(entry,ensure_ascii=False)+"\n")
        st.success(f"Approved entry appended to {logpath.name}.")
with col2:
    if st.button("Approve & create email draft", disabled=not approve):
        (OUT / "email_draft.txt").write_text(email_text,encoding="utf-8")
        st.success("Email draft file created. It has not been sent.")
st.caption("This prototype uses local-file adapters to simulate MCP tool actions. Connect a real MCP server (e.g., Google Docs/Notion and Gmail) to write to external systems. Approval is enforced in the UI before either write.")
