# Groww Review Intelligence + MCP Approval Gate

## What it does
- Loads a reviews CSV and assigns each review to one of five rule-based themes.
- Ranks the top three themes and displays candidate fee-related reviews.
- Generates a weekly product pulse and a neutral mutual-fund expense-ratio explainer.
- Requires explicit user approval before appending a JSONL entry to the Notes log or writing an email draft.
- Does not auto-send email.

## Important evidence limitation
`data/reviews_sample.csv` intentionally combines a few short public review excerpts with clearly labelled `synthetic_demo` rows. The synthetic rows demonstrate how the fee-confusion workflow operates; they are not real customer reviews and must not be quoted as authentic evidence. In particular, the sample does **not** prove that expense-ratio confusion recurs in real reviews. Replace synthetic rows with verified reviews from the selected 8–12 week window before submitting findings as real-world research. The app preserves `record_type` to make this distinction visible.

## Run locally
1. Install Python 3.10+.
2. Create a virtual environment (recommended).
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Start the app:
   ```bash
   streamlit run app.py
   ```
5. Upload a review CSV or use the sample.
6. Inspect theme counts, review evidence, product pulse, and fee explainer.
7. Check the approval box. Then click one of the approval-gated action buttons.

## CSV schema
Required column: `review_text`.
Recommended columns: `date`, `rating`, `source`, `source_url`, `record_type`.
Use `record_type=public_excerpt` only when you have verified the review's wording/date/source. Use `synthetic_demo` for fabricated test records.

## Where MCP approval happens
The approval gate is in `app.py` under **MCP-style approval gate**. Both write buttons are disabled until the reviewer checks the explicit approval box. After approval:
- **Notes log** appends a JSON object to `outputs/notes_log.jsonl` with `date`, `top_themes`, `weekly_pulse`, `identified_fee_issue`, `explanation_bullets`, and `source_links`.
- **Email draft** writes `outputs/email_draft.txt`; no sending function exists.

This is an MCP-style local adapter, not a live external MCP integration. To connect actual tools, replace the local write functions with MCP client calls to a Notes/Docs tool and an email provider's draft-creation tool. Keep approval validation before every external write; never call a send-email tool.

## Classification logic
A transparent keyword-based baseline is used so the demo is inspectable. For production, use an LLM to classify into at most five fixed themes, retain source review IDs and exact quote spans, score confidence, and require human review for low-confidence or fee-related claims.

## Source list
See [`sources.md`](sources.md). Official fee references:
- https://groww.in/help/mutual-funds/searchable/what-are-the-charges-for-mutual-fund-investments--93
- https://groww.in/updates/groww-now-shows-base-expense-ratio-instead-of-total-expense-ratio

## Sample deliverables
- `outputs/weekly_product_pulse.md`
- `outputs/fee_explainer.md`
- `outputs/email_draft.txt`
- `data/reviews_sample.csv`

## Safety and quality checks
- Never represent synthetic records as real reviews.
- Do not infer a recurring fee issue if no authentic review evidence supports it.
- Verify fee details against official, current Groww sources before customer use.
- The email remains a draft and is never automatically sent.
